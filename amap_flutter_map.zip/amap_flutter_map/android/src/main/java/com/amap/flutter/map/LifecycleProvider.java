package com.amap.flutter.map;

import androidx.lifecycle.Lifecycle;

/**
 * @author whm
 * @date 2020/11/8 6:17 PM
 * @mail hongming.whm@alibaba-inc.com
 * @since
 */
public interface LifecycleProvider {
    Lifecycle getLifecycle();
}
