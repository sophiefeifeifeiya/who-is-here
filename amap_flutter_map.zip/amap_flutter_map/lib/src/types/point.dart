/// 屏幕坐标对象，单位为像素
class Point {
  final double x;
  final double y;

  const Point(this.x, this.y);

  dynamic toJson() {
    return <double>[x, y];
  }

  /// 根据传入的坐标数组 \[x, y\] 序列化一个Point对象.
  static Point? fromJson(dynamic json) {
    if (json == null) {
      return null;
    }
    return Point(json[0], json[1]);
  }
}
