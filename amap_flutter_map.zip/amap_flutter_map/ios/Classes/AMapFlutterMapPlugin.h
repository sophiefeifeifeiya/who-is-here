#import <Foundation/Foundation.h>
#import <Flutter/Flutter.h>

@interface AMapFlutterMapPlugin : NSObject<FlutterPlugin>
@end
